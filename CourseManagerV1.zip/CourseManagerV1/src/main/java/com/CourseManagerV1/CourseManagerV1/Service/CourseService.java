package com.CourseManagerV1.CourseManagerV1.Service;

import com.CourseManagerV1.CourseManagerV1.dto.CourseDTO;
import com.CourseManagerV1.CourseManagerV1.Model.Course;
import com.CourseManagerV1.CourseManagerV1.Repository.CourseRepository;
import com.CourseManagerV1.CourseManagerV1.Repository.EnrollmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CourseService {

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private EnrollmentRepository enrollmentRepository;

    public List<CourseDTO> getAvailableCourses() {
        return courseRepository.findAll().stream()
                .map(c -> new CourseDTO(
                        c.getId(),
                        c.getName(),
                        c.getDuration(),
                        c.getSession(),
                        c.getTotalSlots(),
                        c.getFilledSlots()
                ))
                .collect(Collectors.toList());
    }
    public boolean enrollCourse(String studentEmail, Long courseId) {
        Optional<Course> courseOpt = courseRepository.findById(courseId);
        if (courseOpt.isPresent()) {
            Course course = courseOpt.get();
            if (course.getFilledSlots() < course.getTotalSlots()) {
                course.setFilledSlots(course.getFilledSlots() + 1);
                courseRepository.save(course);
                // You should also create an Enrollment record here.
                return true;
            }
        }
        return false;
    }
    public List<CourseDTO> getEnrolledCourses(String studentEmail) {
        return enrollmentRepository.findByStudentEmail(studentEmail).stream()
                .map(e -> {
                    Course c = e.getCourse();
                    return new CourseDTO(
                            c.getId(),
                            c.getName(),
                            c.getDuration(),
                            c.getSession(),
                            c.getTotalSlots(),
                            c.getFilledSlots()
                    );
                })
                .collect(Collectors.toList());
    }

    public boolean unenrollCourse(String studentEmail, Long courseId) {
        Optional<Course> courseOpt = courseRepository.findById(courseId);
        if (courseOpt.isPresent()) {
            Course course = courseOpt.get();
            if (!enrollmentRepository.existsByStudentEmailAndCourseId(studentEmail, courseId)) {
                return false;
            }

            enrollmentRepository.deleteByStudentEmailAndCourseId(studentEmail, courseId);
            course.setFilledSlots(course.getFilledSlots() - 1);
            courseRepository.save(course);
            return true;
        }
        return false;
    }

    public CourseDTO addCourse(CourseDTO courseDTO) {
        Course course = new Course();
        course.setName(courseDTO.getName());
        course.setDuration(courseDTO.getDuration());
        course.setSession(courseDTO.getSession());
        course.setTotalSlots(courseDTO.getTotalSlots());
        course.setFilledSlots(courseDTO.getFilledSlots());

        Course savedCourse = courseRepository.save(course);
        return new CourseDTO(
                savedCourse.getId(),
                savedCourse.getName(),
                savedCourse.getDuration(),
                savedCourse.getSession(),
                savedCourse.getTotalSlots(),
                savedCourse.getFilledSlots()
        );
    }
}
