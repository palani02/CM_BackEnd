package com.CourseManagerV1.CourseManagerV1.Repository;

import com.CourseManagerV1.CourseManagerV1.Model.Enrollment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {
    List<Enrollment> findByStudentEmail(String email);
    void deleteByStudentEmailAndCourseId(String email, Long courseId);
    boolean existsByStudentEmailAndCourseId(String email, Long courseId);
}