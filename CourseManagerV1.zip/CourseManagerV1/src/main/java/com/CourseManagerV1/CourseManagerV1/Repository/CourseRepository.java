package com.CourseManagerV1.CourseManagerV1.Repository;

import com.CourseManagerV1.CourseManagerV1.Model.Course;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseRepository extends JpaRepository<Course, Long> {
}
